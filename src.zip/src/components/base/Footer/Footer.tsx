
import classes from "./Footer.module.scss" 

export default function Footer(){


    return(
        <>
            <div className={classes.wrapper}>

            </div>
        </>
    )
}